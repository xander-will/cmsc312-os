#pragma once

void ParseArgs(int, char**);
char **ScrapeFiles(char*, int*);